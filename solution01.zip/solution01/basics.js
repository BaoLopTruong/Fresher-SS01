function formatMoney(num) {
    let stringNum = String(num);
    let integerString = stringNum.split(".")[0];
    let decimalString = stringNum.split(".")[1];
    let result = '';
    let count = 0;
    for (let i = integerString.length - 1; i >= 0; i--) {
        result = integerString[i] + result;
        count++;
        if ((i !== 0) && (count === 3)) {
            result = "," + result;
            count = 0;
        }
    }
    if (decimalString) {
        result = result + "." + decimalString;
    }
    console.log(result);
    return result;
}

function formatMoney2(money) {
    return Intl.NumberFormat('en-US').format(money)
}

function formatNumber3(num) {
    return Number(num).toLocaleString("en");
}

function formatMoney(price) {
    const prices = parseFloat(price).toFixed(2).split('');
    let index = prices.length - 3;
    while((index -= 3) > 0) {
        prices.splice(index, 0 ,',');
    }
    console.log('format money: ' , prices.join(''));   
}

function formatWallet(money, digits) {
    const moneyTypes = [
        { value: 1, symbol: "" },
        { value: 1E3, symbol: "K" },
        { value: 1E6, symbol: "M" },// 2
        { value: 1E9, symbol: "B" }, // 3
    ];
    let index;
    for (index = moneyTypes.length - 1; index > 0; index--) {
        if (money >= moneyTypes[index].value) {
            break;
        }
    }
    return (money / moneyTypes[index].value).toFixed(digits) + moneyTypes[index].symbol;;
}
// 900,000,000

function factorial(n) {
    return n < 2 ? 1 : n * factorial(n - 1);
}

function getRandomElement(array) {
    return array[Math.floor(Math.random() * array.length)];
}

function pickOutRandomElement(array) {
    return array.splice(Math.floor(Math.random() * array.length), 1);
}

function findMissingElements(arr1, arr2) {
    return arr2.filter(item => !arr1.includes(item));
}

function findMissingElements2(array1, array2) {
    const map = {};
    array1.forEach(element => {
        map[element] = true;
    });
    return array2.filter(num => !map1[num]);
}

// I:1, V:5, X:10, L:50, C:100, D:500