const units = ["", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX"];
const dozens = ["", "X", "XX", "XXX", "XL", "L", "LX", "LXX", "LXXX", "XC"];
const hundreds = ["", "C", "CC", "CCC", "CD", "D", "DC", "DCC", "DCCC", "CM"];

function getRomanNumber(num) {
    if (num === 0) return "";
    let result = "";
    const numString = String(num);
    const len = numString.length;
    for (let i = 0; i < len; i++) {
        const number = numString[len - 1 - i];
        if (i === 0) {
            result = units[number];
        } else if (i === 1) {
            result = dozens[number] + result;
        } else if (i === 2) {
            result = hundreds[number] + result;
        }
    }
    return result;
}

console.log(getRomanNumber(123));
console.log(getRomanNumber(926));