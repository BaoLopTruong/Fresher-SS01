let garden = [
    [0, 1, 0], // 2
    [0, 1, 0],
    [0, 1, 1],
    [0, 1, 1],
    [0, 1, 1]
];
// [ 0, 2 ]
// col = 1 _ temp = [];
    // row 0 - temp = [00, 20] 
    // row 2 - newPath = [02, 22] => temp = [ 00, 20, 02, 22]
        
    //  results = temp

    // think - test = 70%
// ["00000", '20000', '02000', '22000']

function getPaths(garden) {
    let results = [];
    garden[0].forEach((item, row) => (item === 0) && results.push('' + row));
    if (results.length === 0) return;
    for (let col = 1; col < 5; col++) {
        let temp = [];
        for (let row = 0; row < 3; row++)
            if (garden[col][row] === 0) {
                temp = temp.concat(results.slice().map(path => path + row));
            }
        results = temp;
    }
    return results;
}
console.log(getPaths(garden));

